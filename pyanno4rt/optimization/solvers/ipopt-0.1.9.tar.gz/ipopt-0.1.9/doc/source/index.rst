.. cyipopt documentation master file, created by
   sphinx-quickstart on Sat Mar 10 21:53:11 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cyipopt's documentation!
===================================

:mod:`ipopt` Package
--------------------

.. automodule:: ipopt.__init__
    :members:
    :undoc-members:
    :show-inheritance:

Contents:

.. toctree::
   :maxdepth: 2

   install
   tutorial
   reference


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

